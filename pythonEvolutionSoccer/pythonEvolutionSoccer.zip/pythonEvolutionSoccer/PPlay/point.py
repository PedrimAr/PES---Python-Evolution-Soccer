"""A Point class"""
class Point():
    def __init__(self, x, y):
        self.x = x
        self.y = y
